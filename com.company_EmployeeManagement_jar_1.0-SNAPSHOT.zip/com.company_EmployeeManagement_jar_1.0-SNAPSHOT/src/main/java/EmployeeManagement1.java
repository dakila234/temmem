
import employee.EmployeeView;
import employmentdetails.EmploymentDetailsView;
import payroll.PayrollView;
import attendance.AttendanceView;
import employee.EmployeeController;
import employmentdetails.EmploymentDetailsController;
import payroll.PayrollController;
import attendance.AttendanceController;
import dashboard.DashboardView;

public class EmployeeManagement1 {

    public static void main(String[] args) {

        java.awt.EventQueue.invokeLater(() -> {

            EmployeeView ev = new EmployeeView();
            EmploymentDetailsView edv = new EmploymentDetailsView();
            PayrollView pv = new PayrollView();
            AttendanceView av = new AttendanceView();

            new EmployeeController(ev);
            new EmploymentDetailsController(edv);
            new PayrollController(pv);
            new AttendanceController(av);

            DashboardView dashboard
                    = new DashboardView(ev, edv, pv, av);

            dashboard.setVisible(true);
        });
    }
}
